package SortComparator;


import java.util.Comparator;

import Domain.City;
import Domain.Person;

public class CityComparator implements Comparator<Person>  {
	
    public CityComparator() {
	// TODO Auto-generated constructor stub
    }
	
    private Comparator<Person> comparatorOne;
    private Comparator<Person> comparatorTwo;

    public CityComparator(Comparator<Person> o1,Comparator<Person> o2) {
        this.comparatorOne = o1;
        this.comparatorTwo = o2;
    }

    @Override
    public int compare(Person o1, Person o2) {
     
        int comparisonByOne = o1.getAddress().getCity().getCountry().getCountryname().compareTo(o2.getAddress().getCity().getCountry().getCountryname());

       
        if (comparisonByOne == 0) {
            
            return o1.getAddress().getCity().getCityname().compareTo(o2.getAddress().getCity().getCityname());
        } else {
            
            return comparisonByOne;
        }
    }

}
