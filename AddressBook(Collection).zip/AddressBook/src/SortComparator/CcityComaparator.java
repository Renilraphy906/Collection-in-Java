package SortComparator;

import java.util.Comparator;

import Domain.Person;

public class CcityComaparator implements Comparator<Person> {

	public CcityComaparator() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public int compare(Person o1, Person o2) {
		// TODO Auto-generated method stub
		return o1.getAddress().getCity().getCityname().compareTo(o2.getAddress().getCity().getCityname());
	}
	
	

}
