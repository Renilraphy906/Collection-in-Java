package SortComparator;

import java.util.Comparator;

import Domain.Person;

public class FirstNameComparator implements Comparator<Person> {

	private Comparator<Person> comparatorOne;
    private Comparator<Person> comparatorTwo;
    

    public FirstNameComparator(Comparator<Person> o1,Comparator<Person> o2) {
        this.comparatorOne = o1;
        this.comparatorTwo = o2;
    }

    public FirstNameComparator() {
		// TODO Auto-generated constructor stub
	}

	@Override
    public int compare(Person o1, Person o2) {
     
        int comparisonByOne = o1.getAddress().getCity().getCountry().getCountryname().compareTo(o2.getAddress().getCity().getCountry().getCountryname());

       
        if (comparisonByOne == 0) {
            
            int compareByTwo = o1.getAddress().getCity().getCityname().compareTo(o2.getAddress().getCity().getCityname());
            
            if(compareByTwo == 0)
            {
            	return o1.getFirstname().compareTo(o2.getFirstname());
            }else {
                
                return compareByTwo;
            }
        
        }else {
        	return comparisonByOne;
        }
    }
}
