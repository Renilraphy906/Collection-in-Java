package SortComparator;

import java.util.Comparator;

import Domain.Person;

public class CountryComparator implements Comparator<Person> {

	public CountryComparator() {
		// TODO Auto-generated constructor stub
	}
	@Override
	public int compare(Person o1, Person o2) {
		// TODO Auto-generated method stub
		return o1.getAddress().getCity().getCountry().getCountryname().compareTo(o2.getAddress().getCity().getCountry().getCountryname());
	}

}
