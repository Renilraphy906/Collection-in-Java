package SortComparator;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import Domain.Person;

public class SortAllData
{
	public void sortComparator(ArrayList<Person> personList)
	{
		Collections.sort(personList,new CityComparator());
	}
	
	public void cityComparator(ArrayList<Person> personList)
	{
		Collections.sort(personList,new CcityComaparator());
	}
	public void countryComparator(ArrayList<Person> personList)
	{
		Collections.sort(personList,new CountryComparator());
	}
	public void firstNameComparator(ArrayList<Person> personList)
	{
		Collections.sort(personList,new FirstNameComparator());
	}
	public void ageComparator(ArrayList<Person> personList)
	{
		Collections.sort(personList,new AgeComparator().reversed());
	}
	
}
