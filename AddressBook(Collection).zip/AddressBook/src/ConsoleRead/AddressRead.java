package ConsoleRead;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import Data.CityDataAccessObject;
import Data.CountryDataAccessObject;
import Data.FileDataAccessObject;
import Domain.Address;
import Domain.City;
import Domain.Country;
import Services.CityService;
import Services.CountryService;

public class AddressRead {
	
	int a,d = 0;
	
	public Address readAddress() throws IOException
	{
		
		String b,c,f,str1;
		long e ;
		
		Scanner obj = new Scanner(System.in);
		
		City city = new City();
		CityRead cityrea = new CityRead();
		FileDataAccessObject fdao = new CityDataAccessObject("Files/City.txt");
		CityService cs = new CityService(fdao);
		Country cont = new Country();

		
		System.out.println("Enter the Room Number   :   ");
		a = obj.nextInt();
		
		System.out.println("Enter the Building   :   ");
		b = obj.next();
		
		System.out.println("Enter the Street   :   ");
		c = obj.next();
		
		
		do
		{
		
		System.out.println();
		System.out.println("==========City List==========");
		ArrayList<City> cit = cs.findAll();
		Iterator itr = cit.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println();
		
		
		System.out.println("Is City existing in this list(y/n)  ? ");
		str1 = obj.next();
		
		if(str1.equals("y"))
		{
			System.out.println("Enter the City ID   :  ");
			d = obj.nextInt();			
		}
		else
		{
			cs.add(cityrea.readCity());
		}
		
		}while(!str1.equals("y"));
		
		cs.findAll().forEach(data ->{
			int g = Integer.valueOf(data.getCityid());
			if(g==d)
			{
				cont.setCountryid(data.getCountry().getCountryid());
			}
		});
		
		
		System.out.println();
		
		System.out.println("Enter the Phone Number   :   ");
		e = obj.nextLong();
		
		System.out.println("Enter the Email Address   :   ");
		f = obj.next();
		
		city.setCityid(d);
		city.setCountry(cont);
		
		Address address = new Address(a,b,c,city,e,f);
		
		
		return address;
		
	}

	
}
