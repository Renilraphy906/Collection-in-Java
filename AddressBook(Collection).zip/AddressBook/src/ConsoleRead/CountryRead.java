package ConsoleRead;

import java.util.Scanner;

import org.omg.Messaging.SyncScopeHelper;

import Domain.Country;

public class CountryRead {
	
	public Country readCountry()
	{
		int a;
		String b;
		
		Scanner obj = new Scanner(System.in);

		System.out.println("Enter the Country ID  :  ");
		a = obj.nextInt();
		
		System.out.println("Enter the Country Name  :  ");
		b = obj.next();
		
		Country con = new Country(a,b);
	
		return con;
		
	}
}
