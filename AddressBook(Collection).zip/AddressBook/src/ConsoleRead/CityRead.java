package ConsoleRead;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import Data.CountryDataAccessObject;
import Data.FileDataAccessObject;
import Domain.City;
import Domain.Country;
import Services.CountryService;

public class CityRead {
	
	public City readCity() throws IOException
	{
		int a,b = 0;
		String str , str1;
		
		Scanner obj = new Scanner(System.in);
		
		Country con = new Country();
		City city = new City();
		CountryRead counrea = new CountryRead();
		FileDataAccessObject fdao = new CountryDataAccessObject("Files/Country.txt");
		CountryService cs = new CountryService(fdao);

		
		System.out.println("Enter the City ID   :  ");
		a = obj.nextInt();
		
		System.out.println("Enter the City Name   :   ");
		str = obj.next();
		
		do
		{
		
		System.out.println();
		System.out.println("==========Country List==========");
		ArrayList<Country> country = cs.findAll();
		Iterator itr = country.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		
		System.out.println();
		
		
		System.out.println("Is Country existing in this list(y/n)  ? ");
		str1 = obj.next();
		
		if(str1.equals("y"))
		{
			System.out.println("Enter the Country ID   :  ");
			b = obj.nextInt();			
		}
		else
		{
			cs.add(counrea.readCountry());
		}
		
		}while(!str1.equals("y"));
		System.out.println();
		
		
		
		city.setCityid(a);
		city.setCityname(str);
		con.setCountryid(b);
		city.setCountry(con);
		
		System.out.println(city);
		
		return city;
	}

}
