package ConsoleRead;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import Data.AddressDataAccessObject;
import Data.CityDataAccessObject;
import Data.CountryDataAccessObject;
import Data.FileDataAccessObject;
import Domain.Address;
import Domain.City;
import Domain.Country;
import Domain.Person;
import Services.AddressService;
import Services.CityService;

public class PersonRead {

	int d = 0;

	public Person readPerson() throws IOException
	{
		String a,b,c,e,f,str1;
		LocalDate ld;
		
		Address addr = new Address();
		FileDataAccessObject fdao = new AddressDataAccessObject("Files/Address.txt");
		FileDataAccessObject fdao1 = new CityDataAccessObject("Files/City.txt");
		AddressService as = new AddressService(fdao);
		AddressRead are = new AddressRead();
		Address addre = new Address();
		City citt = new City();
		CityService cs = new CityService(fdao1);
		Country con = new Country();
		
		Scanner obj = new Scanner(System.in);
		
		System.out.println("Enter the First Name   :   ");
		a = obj.next();
		
		System.out.println("Enter the Last Name   :   ");
		b = obj.next();
		
		System.out.println("Enter the Date Of Birth(DD-MM-YYYY)   :   ");
		c = obj.next();
		
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate localDate = LocalDate.parse(c, formatter);

				do
				{
				
				System.out.println();
				System.out.println("==========Address List==========");
				ArrayList<Address> address = as.findAll();
				Iterator itr = address.iterator();
				
				while(itr.hasNext())
				{
					System.out.println(itr.next());
				}
				
				System.out.println();
				
				
				System.out.println("Is your Address existing in this list(y/n)  ? ");
				str1 = obj.next();
				
				if(str1.equals("y"))
				{
					System.out.println("Enter the Room Number   :  ");
					d = obj.nextInt();		
					addre.setRoomno(d);
					
				}
				else
				{
					as.add(are.readAddress());
				}
				
				}while(!str1.equals("y"));
				
				as.findAll().forEach(data ->{
					int g = Integer.valueOf(data.getRoomno());
					if(g==d)
					{
//						System.out.println(data.getCity().getCityid());
						int x =data.getCity().getCityid();
						citt.setCityid(x);
						try {
							cs.findAll().forEach(cityData ->{
								int y = cityData.getCityid();
								if(y == x)
								{
									con.setCountryid(cityData.getCountry().getCountryid());
									citt.setCountry(con);
								}
							});
						} catch (Exception e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						
					}
				});
				
				addre.setCity(citt);
		
		System.out.println("Enter your Home Address   :   ");
		e = obj.next();
		
		System.out.println("Enter the Work Address   :   ");
		f = obj.next();
		
		Person per = new Person(a,b,localDate,addre,e,f);
		
		return per;
	}
}
