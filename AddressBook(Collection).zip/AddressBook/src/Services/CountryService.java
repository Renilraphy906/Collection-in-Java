package Services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import Data.DataAccessObject;
import Domain.Country;

public class CountryService {
	DataAccessObject dao;
	
	public CountryService(DataAccessObject dao)
	{
		this.dao = dao;
	}
	
	public void add(Country con) throws IOException
	{
		dao.insert(con);
	}

	public ArrayList<Country> findAll() throws IOException
	{
		
		ArrayList<Object> obj = dao.findAll(); 
		ArrayList<Country> cont = new ArrayList<Country>();		
		Iterator itr = obj.iterator();

		while(itr.hasNext())
		{
			Country con =(Country)itr.next();
			cont.add(con);
		}
		return cont;
	}
	
}
