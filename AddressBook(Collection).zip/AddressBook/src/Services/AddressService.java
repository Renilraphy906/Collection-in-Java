package Services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import Data.AddressDataAccessObject;
import Data.DataAccessObject;
import Data.FileDataAccessObject;
import Domain.Address;
import Domain.Person;
import Main.Menu;

public class AddressService {
	DataAccessObject dao;
	
	public AddressService(DataAccessObject dao)
	{
		this.dao = dao;
	}
	public void add(Address address) throws IOException
	{
		dao.insert(address);
	}
	public ArrayList<Address> findAll() throws IOException
	{
		ArrayList<Object> obj = dao.findAll();
		ArrayList<Address> address = new ArrayList<Address>();
		Iterator itr = obj.iterator();
		while(itr.hasNext())
		{
			Address addr = (Address)itr.next();
			address.add(addr);
		}
		return address;
	}
	
}
