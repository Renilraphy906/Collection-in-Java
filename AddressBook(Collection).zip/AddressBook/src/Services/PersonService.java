package Services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import Data.AddressDataAccessObject;
import Data.CityDataAccessObject;
import Data.CountryDataAccessObject;
import Data.DataAccessObject;
import Data.FileDataAccessObject;
import Data.PersonDataAccessObject;
import Domain.Address;
import Domain.City;
import Domain.Country;
import Domain.Person;

public class PersonService {
	DataAccessObject dao;
	Person per;

	public PersonService(DataAccessObject dao) {
		this.dao = dao;
	}

	public void add(Person person) throws IOException {
		dao.insert(person);
	}

	public ArrayList<Person> findAll() throws IOException {
		ArrayList<Object> obj = dao.findAll();
		ArrayList<Person> person = new ArrayList<Person>();
		obj.forEach(arrli -> {
			per = (Person) arrli;
			person.add(per);
		});

		return person;
	}
	
	public ArrayList<Person> personList() throws IOException {
		ArrayList<Person> personList = new ArrayList<Person>();

		FileDataAccessObject fdao4 = new PersonDataAccessObject("Files/Person.txt");
		PersonService ps = new PersonService(fdao4);
		Person per = new Person();

		ps.findAll().forEach(n -> {
			FileDataAccessObject fdao = new AddressDataAccessObject("Files/Address.txt");
			AddressService as = new AddressService(fdao);

			FileDataAccessObject fdao1 = new CityDataAccessObject("Files/City.txt");
			CityService cs = new CityService(fdao1);

			FileDataAccessObject fdao2 = new CountryDataAccessObject("Files/Country.txt");
			CountryService cos = new CountryService(fdao2);
			Address addre = new Address();
			City city = new City();
			Country count = new Country();
			try {
				as.findAll().forEach(m -> {
					if (n.getAddress().getRoomno() == m.getRoomno()) {
						addre.setRoomno(m.getRoomno());
						addre.setBuilding(m.getBuilding());
						addre.setStreet(m.getStreet());
						addre.setCity(city);
						addre.setPhoneno(m.getPhoneno());
						addre.setEmail(m.getEmail());

						try {
							cs.findAll().forEach(o -> {
								if (n.getAddress().getCity().getCityid() == o.getCityid()) {
									city.setCityid(o.getCityid());
									city.setCityname(o.getCityname());
									city.setCountry(count);

									try {
										cos.findAll().forEach(p -> {
											if (n.getAddress().getCity().getCountry().getCountryid() == p
													.getCountryid()) {
												count.setCountryid(p.getCountryid());
												count.setCountryname(p.getCountryname());
											}
										});
									} catch (Exception e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
							});
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				});
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			n.setAddress(addre);
			personList.add(n);
		});

		return personList;
	}

	public Map<Country, ArrayList<Person>> mapList() throws IOException {
		ArrayList<Person> personList = personList();

		FileDataAccessObject fda = new CountryDataAccessObject("Files/Country.txt");
		CountryService cs = new CountryService(fda);
		Map<Country, ArrayList<Person>> map = new HashMap<Country, ArrayList<Person>>();

		ArrayList<Country> con = cs.findAll();
		Iterator itr = con.iterator();

		while (itr.hasNext()) {
			Country cont = (Country) itr.next();

			ArrayList<Person> per = new ArrayList<Person>();
			personList.forEach(n -> {

				if (cont.getCountryname().equals(n.getAddress().getCity().getCountry().getCountryname())) {
					per.add(n);
					map.put(cont, per);
				}
			});
		}

		return map;
	}


	
	public void displayMap() throws IOException {
		Map<Country, ArrayList<Person>> map = mapList();

		Set set = map.entrySet();
		Iterator iter = set.iterator();
		while (iter.hasNext()) {
			System.out.println(iter.next());
		}
	}
	
	public void setPersonList() throws IOException {
		Set<Person> perSet = new HashSet<Person>();

		ArrayList<Person> perlist = findAll();
		perSet.addAll(perlist);

		Iterator itr = perSet.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

	}

}
