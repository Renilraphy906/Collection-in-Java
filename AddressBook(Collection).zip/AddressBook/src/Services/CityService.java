package Services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import Data.DataAccessObject;
import Domain.City;
import Domain.Country;

public class CityService {

	DataAccessObject dao;
	
	public CityService(DataAccessObject dao){
		
		this.dao = dao;
	}
	
	public void add(City city) throws IOException
	{
		dao.insert(city);
	}
	public ArrayList<City> findAll() throws IOException
	{
		
		ArrayList<Object> obj = dao.findAll(); 
		ArrayList<City> city = new ArrayList<City>();		
		Iterator itr = obj.iterator();

		while(itr.hasNext())
		{
			City cit =(City)itr.next();
			city.add(cit);
		}
		return city;
	}
	
}
