package Data;

import Domain.City;
import Domain.Country;

public class CityDataAccessObject extends FileDataAccessObject {

	public CityDataAccessObject(String path) {
		super(path);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String objectToString(Object obj) {
		City con =(City)obj;
		StringBuilder sb = new StringBuilder();
		sb.append(con.getCityid());
		sb.append(",");
		sb.append(con.getCityname());
		sb.append(",");
		sb.append(con.getCountry().getCountryid());

		return sb.toString();
	}

	@Override
	public Object stringToObject(String s) {
		String[] str = s.split(",");
		City city = new City();
		Country con = new Country();
		
		int a = Integer.valueOf(str[0]);
		String b = String.valueOf(str[1]);
		int c = Integer.valueOf(str[2]);
		
		city.setCityid(a);
		city.setCityname(b);
		con.setCountryid(c);
		city.setCountry(con);
		
 		return city;
	}

}
