package Data;
import java.util.ArrayList;

import javax.swing.text.html.HTMLDocument.Iterator;

import Domain.Country;

public class CountryDataAccessObject extends FileDataAccessObject {

	public CountryDataAccessObject(String path) {
		super(path);
		// TODO Auto-generated constructor stub
	}
	public String objectToString(Object obj)
	{	
		Country con =(Country)obj;
		StringBuilder sb = new StringBuilder();
		sb.append(con.getCountryid());
		sb.append(",");
		sb.append(con.getCountryname());
		
		return sb.toString();
	}
	
	public Object stringToObject(String s)
	{			
		String[] arr = s.split(",");
		
			int a = Integer.parseInt(arr[0]);
			String b = String.valueOf(arr[1]);
			Country con = new Country(a, b);
		
		return con;
	}
}
