package Data;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import Domain.Address;
import Domain.City;
import Domain.Country;
import Domain.Person;

public class PersonDataAccessObject extends FileDataAccessObject {

	public PersonDataAccessObject(String path) {
		super(path);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String objectToString(Object obj) {
		
		Person per = (Person) obj;
		
		StringBuilder sb = new StringBuilder();
		
		sb.append(per.getFirstname());
		sb.append(",");
		sb.append(per.getLastname());
		sb.append(",");
		sb.append(per.getDateofbirth());
		sb.append(",");
		sb.append(per.getAddress().getRoomno());
		sb.append(",");
		sb.append(per.getAddress().getCity().getCityid());
		sb.append(",");
		sb.append(per.getAddress().getCity().getCountry().getCountryid());
		sb.append(",");
		sb.append(per.getHomeaddress());
		sb.append(",");
		sb.append(per.getWorkaddress());
		// TODO Auto-generated method stub
		return sb.toString();
	}

	@Override
	public Object stringToObject(String s)
	{
		Address addr = new Address();
		City cit = new City();
		Country con = new Country();
		
		String[] str = s.split(",");
		
		String a =String.valueOf(str[0]);
		String b =String.valueOf(str[1]);
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate c = LocalDate.parse(str[2], formatter);
		
		int d =Integer.valueOf(str[3]);
		addr.setRoomno(d);
		
		int da =Integer.valueOf(str[4]);
		cit.setCityid(da);
		addr.setCity(cit);
		
		int db = Integer.valueOf(str[5]);
		con.setCountryid(db);
		cit.setCountry(con);
		
		String e =String.valueOf(str[6]);
		String f =String.valueOf(str[7]);
		
		Person per = new Person(a,b,c,addr,e,f);
		
			return per;
	}

}
