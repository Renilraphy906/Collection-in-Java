package Data;

import java.io.IOException;
import java.util.ArrayList;

public interface DataAccessObject {

	public void insert(Object obj) throws IOException;
	public ArrayList<Object> findAll() throws IOException;
}
