package Data;

import Domain.Address;
import Domain.City;
import Domain.Country;

public class AddressDataAccessObject extends FileDataAccessObject {

	public AddressDataAccessObject(String path) {
		super(path);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String objectToString(Object obj) {
	
		Address add = (Address)obj;
		StringBuilder sb = new StringBuilder();
		sb.append(add.getRoomno());
		sb.append(",");
		sb.append(add.getBuilding());
		sb.append(",");
		sb.append(add.getStreet());
		sb.append(",");
		sb.append(add.getCity().getCityid());
		sb.append(",");
		sb.append(add.getCity().getCountry().getCountryid());
		sb.append(",");
		sb.append(add.getPhoneno());
		sb.append(",");
		sb.append(add.getEmail());
		
		return sb.toString();
	}

	@Override
	public Object stringToObject(String s) {

		String[] str = s.split(",");
		City city = new City();
		Country con = new Country();
		
		int a = Integer.valueOf(str[0]);
		String b = String.valueOf(str[1]);
		String c = String.valueOf(str[2]);
		int d = Integer.valueOf(str[3]);
		city.setCityid(d);
		int g = Integer.valueOf(str[4]);
		con.setCountryid(g);
		city.setCountry(con);
		long e = Long.valueOf(str[5]);
		String f = String.valueOf(str[6]);
		
		Address address = new Address(a,b,c,city,e,f);
		
		return address;
	}

}
