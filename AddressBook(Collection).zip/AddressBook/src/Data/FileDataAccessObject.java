package Data;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import Domain.Person;

public abstract class FileDataAccessObject implements DataAccessObject {
	
	String path;
	
	public FileDataAccessObject(String path)
	{
		this.path = path;
	}

	public void insert(Object obj) throws IOException
	{
		String s = objectToString(obj);
		File file = new File(path);
		FileWriter fw = new FileWriter(file,true);
		BufferedWriter bw = new BufferedWriter(fw);
		bw.newLine();
		bw.write(s);
		bw.close();
		System.out.println(obj);
		System.out.println("Inserted Succesfully!!!");
	}
	
	public ArrayList<Object> findAll() throws IOException
	{
		String s;
		ArrayList<Object> arrlis = new ArrayList<Object>();
		
		File file = new File(path);
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);
		while((s = br.readLine()) != null)
		{
			Object obj = stringToObject(s);	
			arrlis.add(obj);
		}
		br.close();
		fr.close();
		
		return arrlis;
	}
		
	public abstract String objectToString(Object obj);
	
	public abstract Object stringToObject(String s);
}
