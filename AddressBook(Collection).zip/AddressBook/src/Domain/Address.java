package Domain;

public class Address {
	
	private int roomno;
	private String building;
	private String street;
	City city;
	private long phoneno;
	private String email;
	
	public Address()
	{
		this.roomno = 0;
		this.building = null;
		this.street = null;
		this.city = null;
		this.phoneno = 0;
		this.email = null;
	}
	public Address(int roomno, String building, String street, City city, long phoneno, String email)
	{
		this.roomno = roomno;
		this.building = building;
		this.street = street;
		this.city = city;
		this.phoneno = phoneno;
		this.email = email;
	}
	public int getRoomno() {
		return roomno;
	}
	public void setRoomno(int roomno) {
		this.roomno = roomno;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public City getCity() {
		return city;
	}
	public void setCity(City city) {
		this.city = city;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Address [roomno=" + roomno + ", building=" + building + ", street=" + street + ", city=" + city
				+ ", phoneno=" + phoneno + ", email=" + email + "]";
	}
	

}
