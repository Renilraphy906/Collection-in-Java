package Domain;

public class Country {
	
	private int countryid;
	private String countryname;
	
	public Country(){
		this.countryid = 0;
		this.countryname = null;
	}
	
	public Country(int countryid, String countryname)
	{
		this.countryid = countryid;
		this.countryname = countryname;
	}

	public int getCountryid() {
		return countryid;
	}

	public void setCountryid(int countryid) {
		this.countryid = countryid;
	}

	public String getCountryname() {
		return countryname;
	}

	public void setCountryname(String countryname) {
		this.countryname = countryname;
	}

	@Override
	public String toString() {
		return "Country [countryid=" + countryid + ", countryname=" + countryname + "]";
	}
	

}
