package Domain;

public class City {

	private int cityid;
	private String cityname;
	Country country;
	
	public City()
	{
		this.cityid = 0;
		this.cityname = null;
		this.country = null;
	}
	
	public City(int cityid , String cityname , Country country)
	{
		this.cityid = cityid;
		this.cityname = cityname;
		this.country = country;
	}

	public int getCityid() {
		return cityid;
	}

	public void setCityid(int cityid) {
		this.cityid = cityid;
	}

	public String getCityname() {
		return cityname;
	}

	public void setCityname(String cityname) {
		this.cityname = cityname;
	}

	public Country getCountry() {
		return country;
	}

	public void setCountry(Country country) {
		this.country = country;
	}

	@Override
	public String toString() {
		return "City [cityid=" + cityid + ", cityname=" + cityname + ", country=" + country + "]";
	}
	
}
