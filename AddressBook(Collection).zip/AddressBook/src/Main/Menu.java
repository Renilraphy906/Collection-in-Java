package Main;

import java.io.IOException;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

import ConsoleRead.AddressRead;
import ConsoleRead.CityRead;
import ConsoleRead.CountryRead;
import ConsoleRead.PersonRead;
import Data.AddressDataAccessObject;
import Data.CityDataAccessObject;
import Data.CountryDataAccessObject;
import Data.FileDataAccessObject;
import Data.PersonDataAccessObject;
import Domain.Address;
import Domain.City;
import Domain.Country;
import Domain.Person;
import Services.AddressService;
import Services.CityService;
import Services.CountryService;
import Services.PersonService;
import SortComparator.AgeComparator;
import SortComparator.CityComparator;
import SortComparator.CountryComparator;
import SortComparator.FirstNameComparator;
import SortComparator.SortAllData;

public class Menu {

	private int flag,a=0;

	CountryRead cr = new CountryRead();
	FileDataAccessObject fdao = new CountryDataAccessObject("Files/Country.txt");
	CountryService cs = new CountryService(fdao);
	
	CityRead cityread = new CityRead();
	FileDataAccessObject fdao1 = new CityDataAccessObject("Files/City.txt");
	CityService cityservice = new CityService(fdao);
	
	AddressRead ar = new AddressRead();
	FileDataAccessObject fdao2 = new AddressDataAccessObject("Files/Address.txt");
	AddressService as = new AddressService(fdao2);
	
	PersonRead pr = new PersonRead();
	FileDataAccessObject fdao3 = new PersonDataAccessObject("Files/Person.txt");
	PersonService ps = new PersonService(fdao3);
	
	
	SortAllData sod = new SortAllData();

	public void menu() throws IOException {
		String z = null;

		do {

			ArrayList<Person> personList = ps.personList();

			Scanner obj = new Scanner(System.in);
			System.out.println("=========== MENU ===========");
			System.out.println();

			System.out.println("1.Insert Country Details.");
			System.out.println("2.View Country Deatils.");
			System.out.println("3.Insert City Details.");
			System.out.println("4.View City Deatils.");
			System.out.println("5.Insert Address Details.");
			System.out.println("6.View Address Details.");
			System.out.println("7.Insert Personal Details.");
			System.out.println("8.View Personal Details.");
			System.out.println("9.Sort By City.");
			System.out.println("10.Sort By Country.");
			System.out.println("11.Sort By City and Country.");
			System.out.println("12.Sort By First Name in City and Country.");
			System.out.println("13.Sort By Age in City and Country in Descenting Order.");
			System.out.println("14.Age greater than 25.");
			System.out.println("15.Search personal details by city");
			System.out.println("16.Search age below 20 in given city");
			System.out.println("17.Map -> Address Book.");
			System.out.println("18.Search By Country.");
			System.out.println("19.Avoid Duplicate.");
			System.out.println("20.Exit.");
			System.out.println("Enter your option...");

			try{
				
				a = obj.nextInt();		
				
			}
			catch(InputMismatchException e){
				System.out.println("Entered data is not a number ...Please check your data!!!");
			}
				

			switch (a) {
			case 1:
				cs.add(cr.readCountry());
				break;

			case 2:
				ArrayList<Country> con = cs.findAll();
				Iterator itr = con.iterator();

				while (itr.hasNext()) {
					System.out.println(itr.next());
				}
				break;

			case 3:
				cityservice.add(cityread.readCity());
				break;

			case 4:
				ArrayList<City> cit = cityservice.findAll();
				itr = cit.iterator();

				while (itr.hasNext()) {
					System.out.println(itr.next());
				}
				break;

			case 5:
				as.add(ar.readAddress());
				break;

			case 6:
				ArrayList<Address> address = as.findAll();
				itr = address.iterator();
				while (itr.hasNext()) {
					System.out.println(itr.next());
				}
				break;

			case 7:
				ps.add(pr.readPerson());
				break;

			case 8:
				ArrayList<Person> per = ps.findAll();
				per.forEach(n -> System.out.println(n));
				break;

			case 9:
				sod.cityComparator(personList);
				personList.forEach(v -> System.out.println(v));
				break;

			case 10:sod.countryComparator(personList);
					personList.forEach(v -> System.out.println(v));
					break;

			case 11:
				sod.cityComparator(personList);
				personList.forEach(nm -> System.out.println(nm));
				break;

			case 12:
				sod.firstNameComparator(personList);
				personList.forEach(nm -> System.out.println(nm));
				break;

			case 13:
				sod.ageComparator(personList);
				personList.forEach(nm -> System.out.println(nm));
				break;

			case 14:
				ageCompare();
				break;

			case 15:
				cityCompare();
				break;

			case 16:
				cityAgeCompare();
				break;

			case 17:
				ps.displayMap();
				break;

			case 18:
				address();
				break;

			case 19:
				ps.setPersonList();
				break;

			case 20:
				System.out.println("Succesfully Exited!!!");
				System.exit(0);
				break;

			default:
				System.out.println("Invalid Entry!!!");
				break;

			}
			Scanner sca = new Scanner(System.in);
			
			System.out.println();
			System.out.println("Do you want to continue ?(y/n)   :   ");
			z = sca.next();
		} while (z.equals("y"));
		if (!z.equals("y")) {
			if (z.equals("n")) {
				System.out.println("Succesfully Exited!!!");
				System.exit(0);
			} else {
				System.out.println("11111");
				System.out.println("Invalid Entry...!!!");
				System.out.println("Succesfully Exited!!!");
				System.exit(0);

			}
		}

	}

	
	public void ageCompare() throws IOException {
		ps.personList().forEach(n -> {
			LocalDate ld = null;
			LocalDate ld1 = n.getDateofbirth();
			ld = ld.now();
			Period diff = Period.between(ld1, ld);
			int a = diff.getYears();
			if (a >= 25) {
				System.out.println(n);
			}
		});
	}

	public void cityCompare() throws IOException {
		this.flag = 0;
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter City Name   :   ");
		String b = obj.next();
		ps.personList().forEach(n -> {
			String a = n.getAddress().getCity().getCityname();
			if (b.equals(a)) {
				System.out.println(n);
				this.flag = 1;
			}
		});
		if (flag == 0) {
			System.out.println(b + "   not in the city list...Try again...");
		}
	}

	public void cityAgeCompare() throws IOException {
		this.flag = 0;
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter City Name   :   ");
		String b = obj.next();
		ps.personList().forEach(n -> {
			String a = n.getAddress().getCity().getCityname();
			if (b.equals(a)) {
				LocalDate ld = null;
				LocalDate ld1 = n.getDateofbirth();
				ld = ld.now();
				Period diff = Period.between(ld1, ld);
				int aa = diff.getYears();
				if (aa <= 20) {
					System.out.println(n);
					this.flag = 1;
				}
			}
		});
		if (flag == 0) {
			System.out.println(b + "   not in the city list...Try again...");
		}
	}

		public void address() throws IOException {
		HashMap<Country, ArrayList<Person>> arrmap = new HashMap<Country, ArrayList<Person>>();

		Scanner obj = new Scanner(System.in);
		System.out.println("Enter the Country Name   :   ");
		String str = obj.next();

		Map<Country, ArrayList<Person>> map =  ps.mapList();

		Set set = map.entrySet();
		Iterator iter = set.iterator();
		while (iter.hasNext()) {
			Map.Entry entry = (Map.Entry) iter.next();
			Country con = (Country) entry.getKey();
			if (con.getCountryname().equals(str)) {
				ArrayList<Person> pers = (ArrayList<Person>) entry.getValue();
				Iterator itre = pers.iterator();
				while (itre.hasNext()) {
					System.out.println(itre.next());
				}
			}

		}

	}


}
