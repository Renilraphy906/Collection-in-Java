package Main;

import java.util.InputMismatchException;

public class MainClass {
	public static void main(String[] args) throws InputMismatchException
	{
		try
		{			
			Menu menu = new Menu();
			menu.menu();	
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
